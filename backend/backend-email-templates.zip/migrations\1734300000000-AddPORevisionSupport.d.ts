import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddPORevisionSupport1734300000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1734300000000-AddPORevisionSupport.d.ts.map