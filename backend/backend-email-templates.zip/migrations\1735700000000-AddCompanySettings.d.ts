import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddCompanySettings1735700000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1735700000000-AddCompanySettings.d.ts.map