import { MigrationInterface, QueryRunner } from "typeorm";
export declare class RenameClientIdToCompanyId1769496670941 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1769496670941-RenameClientIdToCompanyId.d.ts.map