import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddProjectDailyRate1768463761497 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1768463761497-AddProjectDailyRate.d.ts.map