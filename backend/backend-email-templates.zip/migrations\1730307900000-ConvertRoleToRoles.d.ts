import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class ConvertRoleToRoles1730307900000 implements MigrationInterface {
    name: string;
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1730307900000-ConvertRoleToRoles.d.ts.map