import 'reflect-metadata';
//# sourceMappingURL=seed-admin.d.ts.map