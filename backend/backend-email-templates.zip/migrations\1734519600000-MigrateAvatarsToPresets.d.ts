import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class MigrateAvatarsToPresets1734519600000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1734519600000-MigrateAvatarsToPresets.d.ts.map