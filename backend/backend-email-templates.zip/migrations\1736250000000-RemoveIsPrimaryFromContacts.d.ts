import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class RemoveIsPrimaryFromContacts1736250000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1736250000000-RemoveIsPrimaryFromContacts.d.ts.map