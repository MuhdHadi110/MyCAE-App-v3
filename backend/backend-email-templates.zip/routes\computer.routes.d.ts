declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=computer.routes.d.ts.map