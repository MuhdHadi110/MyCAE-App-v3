declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=company.routes.d.ts.map