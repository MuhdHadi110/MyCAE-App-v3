declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=invoice.routes.d.ts.map