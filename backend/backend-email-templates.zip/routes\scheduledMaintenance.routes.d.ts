declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=scheduledMaintenance.routes.d.ts.map