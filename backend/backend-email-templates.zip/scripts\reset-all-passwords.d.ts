import 'reflect-metadata';
//# sourceMappingURL=reset-all-passwords.d.ts.map