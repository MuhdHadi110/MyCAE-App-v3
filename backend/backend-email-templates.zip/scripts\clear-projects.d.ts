import 'reflect-metadata';
//# sourceMappingURL=clear-projects.d.ts.map