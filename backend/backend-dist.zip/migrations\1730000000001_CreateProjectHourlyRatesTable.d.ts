import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class CreateProjectHourlyRatesTable1730000000001 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1730000000001_CreateProjectHourlyRatesTable.d.ts.map