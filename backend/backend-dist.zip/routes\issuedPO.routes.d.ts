declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=issuedPO.routes.d.ts.map