/**
 * Test PDF generation to ensure PDFKit is working correctly
 */
export declare function testPDFGeneration(): Promise<Buffer>;
//# sourceMappingURL=test-pdf.service.d.ts.map