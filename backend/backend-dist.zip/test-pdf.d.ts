import 'reflect-metadata';
//# sourceMappingURL=test-pdf.d.ts.map