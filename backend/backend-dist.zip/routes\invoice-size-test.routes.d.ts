declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=invoice-size-test.routes.d.ts.map