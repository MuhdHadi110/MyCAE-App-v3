import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddInvoiceApprovalWorkflow1735900000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1735900000000-AddInvoiceApprovalWorkflow.d.ts.map