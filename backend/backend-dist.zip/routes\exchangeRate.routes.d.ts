declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=exchangeRate.routes.d.ts.map