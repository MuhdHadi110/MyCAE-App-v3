import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class CreateResearchTimesheetsTable1763030000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1763030000000-CreateResearchTimesheetsTable.d.ts.map