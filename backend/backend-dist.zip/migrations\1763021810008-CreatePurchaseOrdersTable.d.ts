import { MigrationInterface, QueryRunner } from "typeorm";
export declare class CreatePurchaseOrdersTable1763021810008 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1763021810008-CreatePurchaseOrdersTable.d.ts.map