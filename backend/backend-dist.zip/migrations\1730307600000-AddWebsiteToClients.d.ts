import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddWebsiteToClients1730307600000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1730307600000-AddWebsiteToClients.d.ts.map