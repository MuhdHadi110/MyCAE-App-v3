import 'reflect-metadata';
//# sourceMappingURL=seed-data.d.ts.map