import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddPasswordResetFields1736100000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1736100000000-AddPasswordResetFields.d.ts.map