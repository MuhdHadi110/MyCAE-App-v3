declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=client.routes.d.ts.map