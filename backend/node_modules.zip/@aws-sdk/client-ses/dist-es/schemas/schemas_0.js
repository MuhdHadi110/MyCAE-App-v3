const _A = "After";
const _AD = "ArrivalDate";
const _AEE = "AlreadyExistsException";
const _AHA = "AddHeaderAction";
const _ASPE = "AccountSendingPausedException";
const _Ac = "Actions";
const _Act = "Action";
const _B = "Body";
const _BA = "BounceAction";
const _BAc = "BccAddresses";
const _BED = "BulkEmailDestination";
const _BEDL = "BulkEmailDestinationList";
const _BEDS = "BulkEmailDestinationStatus";
const _BEDSL = "BulkEmailDestinationStatusList";
const _BN = "BucketName";
const _BOMXF = "BehaviorOnMXFailure";
const _BRI = "BouncedRecipientInfo";
const _BRIL = "BouncedRecipientInfoList";
const _BS = "BounceSender";
const _BSA = "BounceSenderArn";
const _BT = "BounceType";
const _BTo = "BounceTopic";
const _Bo = "Bounces";
const _Bu = "Bucket";
const _C = "Content";
const _CA = "ConnectAction";
const _CAc = "CcAddresses";
const _CCS = "CreateConfigurationSet";
const _CCSED = "CreateConfigurationSetEventDestination";
const _CCSEDR = "CreateConfigurationSetEventDestinationRequest";
const _CCSEDRr = "CreateConfigurationSetEventDestinationResponse";
const _CCSR = "CreateConfigurationSetRequest";
const _CCSRr = "CreateConfigurationSetResponse";
const _CCSTO = "CreateConfigurationSetTrackingOptions";
const _CCSTOR = "CreateConfigurationSetTrackingOptionsRequest";
const _CCSTORr = "CreateConfigurationSetTrackingOptionsResponse";
const _CCVET = "CreateCustomVerificationEmailTemplate";
const _CCVETR = "CreateCustomVerificationEmailTemplateRequest";
const _CDE = "CannotDeleteException";
const _CRD = "CustomRedirectDomain";
const _CRF = "CreateReceiptFilter";
const _CRFR = "CreateReceiptFilterRequest";
const _CRFRr = "CreateReceiptFilterResponse";
const _CRR = "CreateReceiptRule";
const _CRRR = "CreateReceiptRuleRequest";
const _CRRRr = "CreateReceiptRuleResponse";
const _CRRS = "CloneReceiptRuleSet";
const _CRRSR = "CloneReceiptRuleSetRequest";
const _CRRSRl = "CloneReceiptRuleSetResponse";
const _CRRSRr = "CreateReceiptRuleSetRequest";
const _CRRSRre = "CreateReceiptRuleSetResponse";
const _CRRSr = "CreateReceiptRuleSet";
const _CS = "ConfigurationSet";
const _CSAEE = "ConfigurationSetAlreadyExistsException";
const _CSAN = "ConfigurationSetAttributeNames";
const _CSDNEE = "ConfigurationSetDoesNotExistException";
const _CSN = "ConfigurationSetName";
const _CSSPE = "ConfigurationSetSendingPausedException";
const _CSo = "ConfigurationSets";
const _CT = "ComplaintTopic";
const _CTR = "CreateTemplateRequest";
const _CTRr = "CreateTemplateResponse";
const _CTr = "CreatedTimestamp";
const _CTre = "CreateTemplate";
const _CVEICE = "CustomVerificationEmailInvalidContentException";
const _CVET = "CustomVerificationEmailTemplate";
const _CVETAEE = "CustomVerificationEmailTemplateAlreadyExistsException";
const _CVETDNEE = "CustomVerificationEmailTemplateDoesNotExistException";
const _CVETN = "CustomVerificationEmailTemplateName";
const _CVETu = "CustomVerificationEmailTemplates";
const _CWD = "CloudWatchDestination";
const _CWDC = "CloudWatchDimensionConfiguration";
const _CWDCl = "CloudWatchDimensionConfigurations";
const _Ch = "Charset";
const _Ci = "Cidr";
const _Co = "Complaints";
const _D = "Destination";
const _DA = "DkimAttributes";
const _DARRS = "DescribeActiveReceiptRuleSet";
const _DARRSR = "DescribeActiveReceiptRuleSetRequest";
const _DARRSRe = "DescribeActiveReceiptRuleSetResponse";
const _DAe = "DeliveryAttempts";
const _DC = "DimensionConfigurations";
const _DCS = "DeleteConfigurationSet";
const _DCSED = "DeleteConfigurationSetEventDestination";
const _DCSEDR = "DeleteConfigurationSetEventDestinationRequest";
const _DCSEDRe = "DeleteConfigurationSetEventDestinationResponse";
const _DCSR = "DeleteConfigurationSetRequest";
const _DCSRe = "DeleteConfigurationSetResponse";
const _DCSRes = "DescribeConfigurationSetRequest";
const _DCSResc = "DescribeConfigurationSetResponse";
const _DCSTO = "DeleteConfigurationSetTrackingOptions";
const _DCSTOR = "DeleteConfigurationSetTrackingOptionsRequest";
const _DCSTORe = "DeleteConfigurationSetTrackingOptionsResponse";
const _DCSe = "DescribeConfigurationSet";
const _DCVET = "DeleteCustomVerificationEmailTemplate";
const _DCVETR = "DeleteCustomVerificationEmailTemplateRequest";
const _DCi = "DiagnosticCode";
const _DDV = "DefaultDimensionValue";
const _DE = "DkimEnabled";
const _DI = "DeleteIdentity";
const _DIP = "DeleteIdentityPolicy";
const _DIPR = "DeleteIdentityPolicyRequest";
const _DIPRe = "DeleteIdentityPolicyResponse";
const _DIR = "DeleteIdentityRequest";
const _DIRe = "DeleteIdentityResponse";
const _DN = "DimensionName";
const _DO = "DeliveryOptions";
const _DRF = "DeleteReceiptFilter";
const _DRFR = "DeleteReceiptFilterRequest";
const _DRFRe = "DeleteReceiptFilterResponse";
const _DRR = "DeleteReceiptRule";
const _DRRR = "DeleteReceiptRuleRequest";
const _DRRRe = "DeleteReceiptRuleResponse";
const _DRRRes = "DescribeReceiptRuleRequest";
const _DRRResc = "DescribeReceiptRuleResponse";
const _DRRS = "DeleteReceiptRuleSet";
const _DRRSR = "DeleteReceiptRuleSetRequest";
const _DRRSRe = "DeleteReceiptRuleSetResponse";
const _DRRSRes = "DescribeReceiptRuleSetRequest";
const _DRRSResc = "DescribeReceiptRuleSetResponse";
const _DRRSe = "DescribeReceiptRuleSet";
const _DRRe = "DescribeReceiptRule";
const _DSARN = "DeliveryStreamARN";
const _DT = "DkimTokens";
const _DTD = "DefaultTemplateData";
const _DTR = "DeleteTemplateRequest";
const _DTRe = "DeleteTemplateResponse";
const _DTe = "DeliveryTopic";
const _DTef = "DefaultTags";
const _DTel = "DeleteTemplate";
const _DVEA = "DeleteVerifiedEmailAddress";
const _DVEAR = "DeleteVerifiedEmailAddressRequest";
const _DVS = "DimensionValueSource";
const _DVSk = "DkimVerificationStatus";
const _Da = "Data";
const _De = "Destinations";
const _Do = "Domain";
const _E = "Error";
const _EA = "EmailAddress";
const _ED = "EventDestination";
const _EDAEE = "EventDestinationAlreadyExistsException";
const _EDDNEE = "EventDestinationDoesNotExistException";
const _EDN = "EventDestinationName";
const _EDv = "EventDestinations";
const _EF = "ExtensionField";
const _EFL = "ExtensionFieldList";
const _EFx = "ExtensionFields";
const _En = "Enabled";
const _Enc = "Encoding";
const _Ex = "Explanation";
const _F = "Filter";
const _FA = "FunctionArn";
const _FAr = "FromArn";
const _FE = "ForwardingEnabled";
const _FEA = "FromEmailAddress";
const _FEANVE = "FromEmailAddressNotVerifiedException";
const _FN = "FilterName";
const _FR = "FinalRecipient";
const _FRURL = "FailureRedirectionURL";
const _Fi = "Filters";
const _GASE = "GetAccountSendingEnabled";
const _GASER = "GetAccountSendingEnabledResponse";
const _GCVET = "GetCustomVerificationEmailTemplate";
const _GCVETR = "GetCustomVerificationEmailTemplateRequest";
const _GCVETRe = "GetCustomVerificationEmailTemplateResponse";
const _GIDA = "GetIdentityDkimAttributes";
const _GIDAR = "GetIdentityDkimAttributesRequest";
const _GIDARe = "GetIdentityDkimAttributesResponse";
const _GIMFDA = "GetIdentityMailFromDomainAttributes";
const _GIMFDAR = "GetIdentityMailFromDomainAttributesRequest";
const _GIMFDARe = "GetIdentityMailFromDomainAttributesResponse";
const _GINA = "GetIdentityNotificationAttributes";
const _GINAR = "GetIdentityNotificationAttributesRequest";
const _GINARe = "GetIdentityNotificationAttributesResponse";
const _GIP = "GetIdentityPolicies";
const _GIPR = "GetIdentityPoliciesRequest";
const _GIPRe = "GetIdentityPoliciesResponse";
const _GIVA = "GetIdentityVerificationAttributes";
const _GIVAR = "GetIdentityVerificationAttributesRequest";
const _GIVARe = "GetIdentityVerificationAttributesResponse";
const _GSQ = "GetSendQuota";
const _GSQR = "GetSendQuotaResponse";
const _GSS = "GetSendStatistics";
const _GSSR = "GetSendStatisticsResponse";
const _GT = "GetTemplate";
const _GTR = "GetTemplateRequest";
const _GTRe = "GetTemplateResponse";
const _H = "Html";
const _HIBNE = "HeadersInBounceNotificationsEnabled";
const _HICNE = "HeadersInComplaintNotificationsEnabled";
const _HIDNE = "HeadersInDeliveryNotificationsEnabled";
const _HN = "HeaderName";
const _HP = "HtmlPart";
const _HV = "HeaderValue";
const _I = "Identity";
const _IAMRARN = "IAMRoleARN";
const _IARN = "InstanceARN";
const _ICSE = "InvalidConfigurationSetException";
const _ICWDE = "InvalidCloudWatchDestinationException";
const _IDA = "IdentityDkimAttributes";
const _IDOE = "InvalidDeliveryOptionsException";
const _IF = "IpFilter";
const _IFDE = "InvalidFirehoseDestinationException";
const _ILFE = "InvalidLambdaFunctionException";
const _IMFDA = "IdentityMailFromDomainAttributes";
const _INA = "IdentityNotificationAttributes";
const _IPE = "InvalidPolicyException";
const _IRA = "IamRoleArn";
const _IRPE = "InvalidRenderingParameterException";
const _ISCE = "InvalidS3ConfigurationException";
const _ISNSDE = "InvalidSNSDestinationException";
const _ISTE = "InvalidSnsTopicException";
const _IT = "InvocationType";
const _ITE = "InvalidTemplateException";
const _ITOE = "InvalidTrackingOptionsException";
const _ITd = "IdentityType";
const _IVA = "IdentityVerificationAttributes";
const _Id = "Identities";
const _KFD = "KinesisFirehoseDestination";
const _KKA = "KmsKeyArn";
const _LA = "LambdaAction";
const _LAD = "LastAttemptDate";
const _LCS = "ListConfigurationSets";
const _LCSR = "ListConfigurationSetsRequest";
const _LCSRi = "ListConfigurationSetsResponse";
const _LCVET = "ListCustomVerificationEmailTemplates";
const _LCVETR = "ListCustomVerificationEmailTemplatesRequest";
const _LCVETRi = "ListCustomVerificationEmailTemplatesResponse";
const _LEE = "LimitExceededException";
const _LFS = "LastFreshStart";
const _LI = "ListIdentities";
const _LIP = "ListIdentityPolicies";
const _LIPR = "ListIdentityPoliciesRequest";
const _LIPRi = "ListIdentityPoliciesResponse";
const _LIR = "ListIdentitiesRequest";
const _LIRi = "ListIdentitiesResponse";
const _LRF = "ListReceiptFilters";
const _LRFR = "ListReceiptFiltersRequest";
const _LRFRi = "ListReceiptFiltersResponse";
const _LRRS = "ListReceiptRuleSets";
const _LRRSR = "ListReceiptRuleSetsRequest";
const _LRRSRi = "ListReceiptRuleSetsResponse";
const _LT = "ListTemplates";
const _LTR = "ListTemplatesRequest";
const _LTRi = "ListTemplatesResponse";
const _LVEA = "ListVerifiedEmailAddresses";
const _LVEAR = "ListVerifiedEmailAddressesResponse";
const _M = "Message";
const _MD = "MessageDsn";
const _MET = "MatchingEventTypes";
const _MFD = "MailFromDomain";
const _MFDA = "MailFromDomainAttributes";
const _MFDNVE = "MailFromDomainNotVerifiedException";
const _MFDS = "MailFromDomainStatus";
const _MHS = "Max24HourSend";
const _MI = "MessageId";
const _MIa = "MaxItems";
const _MR = "MaxResults";
const _MRAE = "MissingRenderingAttributeException";
const _MRe = "MessageRejected";
const _MSR = "MaxSendRate";
const _MT = "MessageTag";
const _MTL = "MessageTagList";
const _Me = "Metadata";
const _N = "Name";
const _NA = "NotificationAttributes";
const _NT = "NextToken";
const _NTo = "NotificationType";
const _OA = "OrganizationArn";
const _OKP = "ObjectKeyPrefix";
const _OMI = "OriginalMessageId";
const _ORSN = "OriginalRuleSetName";
const _P = "Policies";
const _PANGE = "ProductionAccessNotGrantedException";
const _PCSDO = "PutConfigurationSetDeliveryOptions";
const _PCSDOR = "PutConfigurationSetDeliveryOptionsRequest";
const _PCSDORu = "PutConfigurationSetDeliveryOptionsResponse";
const _PIP = "PutIdentityPolicy";
const _PIPR = "PutIdentityPolicyRequest";
const _PIPRu = "PutIdentityPolicyResponse";
const _PN = "PolicyName";
const _PNo = "PolicyNames";
const _Po = "Policy";
const _R = "Recipient";
const _RA = "RecipientArn";
const _RAL = "ReceiptActionsList";
const _RAe = "ReceiptAction";
const _RDF = "RecipientDsnFields";
const _RDNEE = "RuleDoesNotExistException";
const _RF = "ReceiptFilter";
const _RFL = "ReceiptFilterList";
const _RIF = "ReceiptIpFilter";
const _RM = "ReportingMta";
const _RME = "ReputationMetricsEnabled";
const _RMa = "RawMessage";
const _RMe = "RemoteMta";
const _RN = "RuleName";
const _RNu = "RuleNames";
const _RO = "ReputationOptions";
const _RP = "ReturnPath";
const _RPA = "ReturnPathArn";
const _RR = "ReceiptRule";
const _RRL = "ReceiptRulesList";
const _RRRS = "ReorderReceiptRuleSet";
const _RRRSR = "ReorderReceiptRuleSetRequest";
const _RRRSRe = "ReorderReceiptRuleSetResponse";
const _RRSL = "ReceiptRuleSetsLists";
const _RRSM = "ReceiptRuleSetMetadata";
const _RS = "RuleSets";
const _RSDNEE = "RuleSetDoesNotExistException";
const _RSN = "RuleSetName";
const _RT = "ReplacementTags";
const _RTA = "ReplyToAddresses";
const _RTD = "ReplacementTemplateData";
const _RTe = "RenderedTemplate";
const _Re = "Recipients";
const _Rej = "Rejects";
const _Ru = "Rule";
const _Rul = "Rules";
const _S = "Sender";
const _SA = "S3Action";
const _SARRS = "SetActiveReceiptRuleSet";
const _SARRSR = "SetActiveReceiptRuleSetRequest";
const _SARRSRe = "SetActiveReceiptRuleSetResponse";
const _SAo = "SourceArn";
const _SAt = "StopAction";
const _SB = "SendBounce";
const _SBR = "SendBounceRequest";
const _SBRe = "SendBounceResponse";
const _SBTE = "SendBulkTemplatedEmail";
const _SBTER = "SendBulkTemplatedEmailRequest";
const _SBTERe = "SendBulkTemplatedEmailResponse";
const _SC = "StatusCode";
const _SCVE = "SendCustomVerificationEmail";
const _SCVER = "SendCustomVerificationEmailRequest";
const _SCVERe = "SendCustomVerificationEmailResponse";
const _SDP = "SendDataPoints";
const _SDPL = "SendDataPointList";
const _SDPe = "SendDataPoint";
const _SE = "ScanEnabled";
const _SER = "SendEmailRequest";
const _SERe = "SendEmailResponse";
const _SEe = "SendingEnabled";
const _SEen = "SendEmail";
const _SIDE = "SetIdentityDkimEnabled";
const _SIDER = "SetIdentityDkimEnabledRequest";
const _SIDERe = "SetIdentityDkimEnabledResponse";
const _SIFFE = "SetIdentityFeedbackForwardingEnabled";
const _SIFFER = "SetIdentityFeedbackForwardingEnabledRequest";
const _SIFFERe = "SetIdentityFeedbackForwardingEnabledResponse";
const _SIHINE = "SetIdentityHeadersInNotificationsEnabled";
const _SIHINER = "SetIdentityHeadersInNotificationsEnabledRequest";
const _SIHINERe = "SetIdentityHeadersInNotificationsEnabledResponse";
const _SIMFD = "SetIdentityMailFromDomain";
const _SIMFDR = "SetIdentityMailFromDomainRequest";
const _SIMFDRe = "SetIdentityMailFromDomainResponse";
const _SINT = "SetIdentityNotificationTopic";
const _SINTR = "SetIdentityNotificationTopicRequest";
const _SINTRe = "SetIdentityNotificationTopicResponse";
const _SLH = "SentLast24Hours";
const _SNSA = "SNSAction";
const _SNSD = "SNSDestination";
const _SP = "SubjectPart";
const _SRC = "SmtpReplyCode";
const _SRE = "SendRawEmail";
const _SRER = "SendRawEmailRequest";
const _SRERe = "SendRawEmailResponse";
const _SRRP = "SetReceiptRulePosition";
const _SRRPR = "SetReceiptRulePositionRequest";
const _SRRPRe = "SetReceiptRulePositionResponse";
const _SRURL = "SuccessRedirectionURL";
const _ST = "SnsTopic";
const _STE = "SendTemplatedEmail";
const _STER = "SendTemplatedEmailRequest";
const _STERe = "SendTemplatedEmailResponse";
const _Sc = "Scope";
const _So = "Source";
const _St = "Status";
const _Su = "Subject";
const _T = "Text";
const _TA = "TopicArn";
const _TARN = "TopicARN";
const _TAe = "TemplateArn";
const _TAo = "ToAddresses";
const _TC = "TemplateContent";
const _TD = "TemplateData";
const _TDNEE = "TemplateDoesNotExistException";
const _TM = "TemplatesMetadata";
const _TML = "TemplateMetadataList";
const _TMe = "TemplateMetadata";
const _TN = "TemplateName";
const _TO = "TrackingOptions";
const _TOAEE = "TrackingOptionsAlreadyExistsException";
const _TODNEE = "TrackingOptionsDoesNotExistException";
const _TP = "TlsPolicy";
const _TPe = "TextPart";
const _TRT = "TestRenderTemplate";
const _TRTR = "TestRenderTemplateRequest";
const _TRTRe = "TestRenderTemplateResponse";
const _TS = "TemplateSubject";
const _Ta = "Tags";
const _Te = "Template";
const _Ti = "Timestamp";
const _To = "Topic";
const _UASE = "UpdateAccountSendingEnabled";
const _UASER = "UpdateAccountSendingEnabledRequest";
const _UCSED = "UpdateConfigurationSetEventDestination";
const _UCSEDR = "UpdateConfigurationSetEventDestinationRequest";
const _UCSEDRp = "UpdateConfigurationSetEventDestinationResponse";
const _UCSRME = "UpdateConfigurationSetReputationMetricsEnabled";
const _UCSRMER = "UpdateConfigurationSetReputationMetricsEnabledRequest";
const _UCSSE = "UpdateConfigurationSetSendingEnabled";
const _UCSSER = "UpdateConfigurationSetSendingEnabledRequest";
const _UCSTO = "UpdateConfigurationSetTrackingOptions";
const _UCSTOR = "UpdateConfigurationSetTrackingOptionsRequest";
const _UCSTORp = "UpdateConfigurationSetTrackingOptionsResponse";
const _UCVET = "UpdateCustomVerificationEmailTemplate";
const _UCVETR = "UpdateCustomVerificationEmailTemplateRequest";
const _URR = "UpdateReceiptRule";
const _URRR = "UpdateReceiptRuleRequest";
const _URRRp = "UpdateReceiptRuleResponse";
const _UT = "UpdateTemplate";
const _UTR = "UpdateTemplateRequest";
const _UTRp = "UpdateTemplateResponse";
const _V = "Value";
const _VA = "VerificationAttributes";
const _VDD = "VerifyDomainDkim";
const _VDDR = "VerifyDomainDkimRequest";
const _VDDRe = "VerifyDomainDkimResponse";
const _VDI = "VerifyDomainIdentity";
const _VDIR = "VerifyDomainIdentityRequest";
const _VDIRe = "VerifyDomainIdentityResponse";
const _VEA = "VerifiedEmailAddresses";
const _VEAR = "VerifyEmailAddressRequest";
const _VEAe = "VerifyEmailAddress";
const _VEI = "VerifyEmailIdentity";
const _VEIR = "VerifyEmailIdentityRequest";
const _VEIRe = "VerifyEmailIdentityResponse";
const _VS = "VerificationStatus";
const _VT = "VerificationToken";
const _WA = "WorkmailAction";
const _aQE = "awsQueryError";
const _c = "client";
const _e = "error";
const _hE = "httpError";
const _m = "message";
const _s = "smithy.ts.sdk.synthetic.com.amazonaws.ses";
const n0 = "com.amazonaws.ses";
import { TypeRegistry } from "@smithy/core/schema";
import { AccountSendingPausedException, AlreadyExistsException, CannotDeleteException, ConfigurationSetAlreadyExistsException, ConfigurationSetDoesNotExistException, ConfigurationSetSendingPausedException, CustomVerificationEmailInvalidContentException, CustomVerificationEmailTemplateAlreadyExistsException, CustomVerificationEmailTemplateDoesNotExistException, EventDestinationAlreadyExistsException, EventDestinationDoesNotExistException, FromEmailAddressNotVerifiedException, InvalidCloudWatchDestinationException, InvalidConfigurationSetException, InvalidDeliveryOptionsException, InvalidFirehoseDestinationException, InvalidLambdaFunctionException, InvalidPolicyException, InvalidRenderingParameterException, InvalidS3ConfigurationException, InvalidSNSDestinationException, InvalidSnsTopicException, InvalidTemplateException, InvalidTrackingOptionsException, LimitExceededException, MailFromDomainNotVerifiedException, MessageRejected, MissingRenderingAttributeException, ProductionAccessNotGrantedException, RuleDoesNotExistException, RuleSetDoesNotExistException, TemplateDoesNotExistException, TrackingOptionsAlreadyExistsException, TrackingOptionsDoesNotExistException, } from "../models/errors";
import { SESServiceException } from "../models/SESServiceException";
export var AccountSendingPausedException$ = [-3, n0, _ASPE,
    { [_aQE]: [`AccountSendingPausedException`, 400], [_e]: _c, [_hE]: 400 },
    [_m],
    [0]
];
TypeRegistry.for(n0).registerError(AccountSendingPausedException$, AccountSendingPausedException);
export var AddHeaderAction$ = [3, n0, _AHA,
    0,
    [_HN, _HV],
    [0, 0], 2
];
export var AlreadyExistsException$ = [-3, n0, _AEE,
    { [_aQE]: [`AlreadyExists`, 400], [_e]: _c, [_hE]: 400 },
    [_N, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(AlreadyExistsException$, AlreadyExistsException);
export var Body$ = [3, n0, _B,
    0,
    [_T, _H],
    [() => Content$, () => Content$]
];
export var BounceAction$ = [3, n0, _BA,
    0,
    [_SRC, _M, _S, _TA, _SC],
    [0, 0, 0, 0, 0], 3
];
export var BouncedRecipientInfo$ = [3, n0, _BRI,
    0,
    [_R, _RA, _BT, _RDF],
    [0, 0, 0, () => RecipientDsnFields$], 1
];
export var BulkEmailDestination$ = [3, n0, _BED,
    0,
    [_D, _RT, _RTD],
    [() => Destination$, () => MessageTagList, 0], 1
];
export var BulkEmailDestinationStatus$ = [3, n0, _BEDS,
    0,
    [_St, _E, _MI],
    [0, 0, 0]
];
export var CannotDeleteException$ = [-3, n0, _CDE,
    { [_aQE]: [`CannotDelete`, 400], [_e]: _c, [_hE]: 400 },
    [_N, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(CannotDeleteException$, CannotDeleteException);
export var CloneReceiptRuleSetRequest$ = [3, n0, _CRRSR,
    0,
    [_RSN, _ORSN],
    [0, 0], 2
];
export var CloneReceiptRuleSetResponse$ = [3, n0, _CRRSRl,
    0,
    [],
    []
];
export var CloudWatchDestination$ = [3, n0, _CWD,
    0,
    [_DC],
    [() => CloudWatchDimensionConfigurations], 1
];
export var CloudWatchDimensionConfiguration$ = [3, n0, _CWDC,
    0,
    [_DN, _DVS, _DDV],
    [0, 0, 0], 3
];
export var ConfigurationSet$ = [3, n0, _CS,
    0,
    [_N],
    [0], 1
];
export var ConfigurationSetAlreadyExistsException$ = [-3, n0, _CSAEE,
    { [_aQE]: [`ConfigurationSetAlreadyExists`, 400], [_e]: _c, [_hE]: 400 },
    [_CSN, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(ConfigurationSetAlreadyExistsException$, ConfigurationSetAlreadyExistsException);
export var ConfigurationSetDoesNotExistException$ = [-3, n0, _CSDNEE,
    { [_aQE]: [`ConfigurationSetDoesNotExist`, 400], [_e]: _c, [_hE]: 400 },
    [_CSN, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(ConfigurationSetDoesNotExistException$, ConfigurationSetDoesNotExistException);
export var ConfigurationSetSendingPausedException$ = [-3, n0, _CSSPE,
    { [_aQE]: [`ConfigurationSetSendingPausedException`, 400], [_e]: _c, [_hE]: 400 },
    [_CSN, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(ConfigurationSetSendingPausedException$, ConfigurationSetSendingPausedException);
export var ConnectAction$ = [3, n0, _CA,
    0,
    [_IARN, _IAMRARN],
    [0, 0], 2
];
export var Content$ = [3, n0, _C,
    0,
    [_Da, _Ch],
    [0, 0], 1
];
export var CreateConfigurationSetEventDestinationRequest$ = [3, n0, _CCSEDR,
    0,
    [_CSN, _ED],
    [0, () => EventDestination$], 2
];
export var CreateConfigurationSetEventDestinationResponse$ = [3, n0, _CCSEDRr,
    0,
    [],
    []
];
export var CreateConfigurationSetRequest$ = [3, n0, _CCSR,
    0,
    [_CS],
    [() => ConfigurationSet$], 1
];
export var CreateConfigurationSetResponse$ = [3, n0, _CCSRr,
    0,
    [],
    []
];
export var CreateConfigurationSetTrackingOptionsRequest$ = [3, n0, _CCSTOR,
    0,
    [_CSN, _TO],
    [0, () => TrackingOptions$], 2
];
export var CreateConfigurationSetTrackingOptionsResponse$ = [3, n0, _CCSTORr,
    0,
    [],
    []
];
export var CreateCustomVerificationEmailTemplateRequest$ = [3, n0, _CCVETR,
    0,
    [_TN, _FEA, _TS, _TC, _SRURL, _FRURL],
    [0, 0, 0, 0, 0, 0], 6
];
export var CreateReceiptFilterRequest$ = [3, n0, _CRFR,
    0,
    [_F],
    [() => ReceiptFilter$], 1
];
export var CreateReceiptFilterResponse$ = [3, n0, _CRFRr,
    0,
    [],
    []
];
export var CreateReceiptRuleRequest$ = [3, n0, _CRRR,
    0,
    [_RSN, _Ru, _A],
    [0, () => ReceiptRule$, 0], 2
];
export var CreateReceiptRuleResponse$ = [3, n0, _CRRRr,
    0,
    [],
    []
];
export var CreateReceiptRuleSetRequest$ = [3, n0, _CRRSRr,
    0,
    [_RSN],
    [0], 1
];
export var CreateReceiptRuleSetResponse$ = [3, n0, _CRRSRre,
    0,
    [],
    []
];
export var CreateTemplateRequest$ = [3, n0, _CTR,
    0,
    [_Te],
    [() => Template$], 1
];
export var CreateTemplateResponse$ = [3, n0, _CTRr,
    0,
    [],
    []
];
export var CustomVerificationEmailInvalidContentException$ = [-3, n0, _CVEICE,
    { [_aQE]: [`CustomVerificationEmailInvalidContent`, 400], [_e]: _c, [_hE]: 400 },
    [_m],
    [0]
];
TypeRegistry.for(n0).registerError(CustomVerificationEmailInvalidContentException$, CustomVerificationEmailInvalidContentException);
export var CustomVerificationEmailTemplate$ = [3, n0, _CVET,
    0,
    [_TN, _FEA, _TS, _SRURL, _FRURL],
    [0, 0, 0, 0, 0]
];
export var CustomVerificationEmailTemplateAlreadyExistsException$ = [-3, n0, _CVETAEE,
    { [_aQE]: [`CustomVerificationEmailTemplateAlreadyExists`, 400], [_e]: _c, [_hE]: 400 },
    [_CVETN, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(CustomVerificationEmailTemplateAlreadyExistsException$, CustomVerificationEmailTemplateAlreadyExistsException);
export var CustomVerificationEmailTemplateDoesNotExistException$ = [-3, n0, _CVETDNEE,
    { [_aQE]: [`CustomVerificationEmailTemplateDoesNotExist`, 400], [_e]: _c, [_hE]: 400 },
    [_CVETN, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(CustomVerificationEmailTemplateDoesNotExistException$, CustomVerificationEmailTemplateDoesNotExistException);
export var DeleteConfigurationSetEventDestinationRequest$ = [3, n0, _DCSEDR,
    0,
    [_CSN, _EDN],
    [0, 0], 2
];
export var DeleteConfigurationSetEventDestinationResponse$ = [3, n0, _DCSEDRe,
    0,
    [],
    []
];
export var DeleteConfigurationSetRequest$ = [3, n0, _DCSR,
    0,
    [_CSN],
    [0], 1
];
export var DeleteConfigurationSetResponse$ = [3, n0, _DCSRe,
    0,
    [],
    []
];
export var DeleteConfigurationSetTrackingOptionsRequest$ = [3, n0, _DCSTOR,
    0,
    [_CSN],
    [0], 1
];
export var DeleteConfigurationSetTrackingOptionsResponse$ = [3, n0, _DCSTORe,
    0,
    [],
    []
];
export var DeleteCustomVerificationEmailTemplateRequest$ = [3, n0, _DCVETR,
    0,
    [_TN],
    [0], 1
];
export var DeleteIdentityPolicyRequest$ = [3, n0, _DIPR,
    0,
    [_I, _PN],
    [0, 0], 2
];
export var DeleteIdentityPolicyResponse$ = [3, n0, _DIPRe,
    0,
    [],
    []
];
export var DeleteIdentityRequest$ = [3, n0, _DIR,
    0,
    [_I],
    [0], 1
];
export var DeleteIdentityResponse$ = [3, n0, _DIRe,
    0,
    [],
    []
];
export var DeleteReceiptFilterRequest$ = [3, n0, _DRFR,
    0,
    [_FN],
    [0], 1
];
export var DeleteReceiptFilterResponse$ = [3, n0, _DRFRe,
    0,
    [],
    []
];
export var DeleteReceiptRuleRequest$ = [3, n0, _DRRR,
    0,
    [_RSN, _RN],
    [0, 0], 2
];
export var DeleteReceiptRuleResponse$ = [3, n0, _DRRRe,
    0,
    [],
    []
];
export var DeleteReceiptRuleSetRequest$ = [3, n0, _DRRSR,
    0,
    [_RSN],
    [0], 1
];
export var DeleteReceiptRuleSetResponse$ = [3, n0, _DRRSRe,
    0,
    [],
    []
];
export var DeleteTemplateRequest$ = [3, n0, _DTR,
    0,
    [_TN],
    [0], 1
];
export var DeleteTemplateResponse$ = [3, n0, _DTRe,
    0,
    [],
    []
];
export var DeleteVerifiedEmailAddressRequest$ = [3, n0, _DVEAR,
    0,
    [_EA],
    [0], 1
];
export var DeliveryOptions$ = [3, n0, _DO,
    0,
    [_TP],
    [0]
];
export var DescribeActiveReceiptRuleSetRequest$ = [3, n0, _DARRSR,
    0,
    [],
    []
];
export var DescribeActiveReceiptRuleSetResponse$ = [3, n0, _DARRSRe,
    0,
    [_Me, _Rul],
    [() => ReceiptRuleSetMetadata$, () => ReceiptRulesList]
];
export var DescribeConfigurationSetRequest$ = [3, n0, _DCSRes,
    0,
    [_CSN, _CSAN],
    [0, 64 | 0], 1
];
export var DescribeConfigurationSetResponse$ = [3, n0, _DCSResc,
    0,
    [_CS, _EDv, _TO, _DO, _RO],
    [() => ConfigurationSet$, () => EventDestinations, () => TrackingOptions$, () => DeliveryOptions$, () => ReputationOptions$]
];
export var DescribeReceiptRuleRequest$ = [3, n0, _DRRRes,
    0,
    [_RSN, _RN],
    [0, 0], 2
];
export var DescribeReceiptRuleResponse$ = [3, n0, _DRRResc,
    0,
    [_Ru],
    [() => ReceiptRule$]
];
export var DescribeReceiptRuleSetRequest$ = [3, n0, _DRRSRes,
    0,
    [_RSN],
    [0], 1
];
export var DescribeReceiptRuleSetResponse$ = [3, n0, _DRRSResc,
    0,
    [_Me, _Rul],
    [() => ReceiptRuleSetMetadata$, () => ReceiptRulesList]
];
export var Destination$ = [3, n0, _D,
    0,
    [_TAo, _CAc, _BAc],
    [64 | 0, 64 | 0, 64 | 0]
];
export var EventDestination$ = [3, n0, _ED,
    0,
    [_N, _MET, _En, _KFD, _CWD, _SNSD],
    [0, 64 | 0, 2, () => KinesisFirehoseDestination$, () => CloudWatchDestination$, () => SNSDestination$], 2
];
export var EventDestinationAlreadyExistsException$ = [-3, n0, _EDAEE,
    { [_aQE]: [`EventDestinationAlreadyExists`, 400], [_e]: _c, [_hE]: 400 },
    [_CSN, _EDN, _m],
    [0, 0, 0]
];
TypeRegistry.for(n0).registerError(EventDestinationAlreadyExistsException$, EventDestinationAlreadyExistsException);
export var EventDestinationDoesNotExistException$ = [-3, n0, _EDDNEE,
    { [_aQE]: [`EventDestinationDoesNotExist`, 400], [_e]: _c, [_hE]: 400 },
    [_CSN, _EDN, _m],
    [0, 0, 0]
];
TypeRegistry.for(n0).registerError(EventDestinationDoesNotExistException$, EventDestinationDoesNotExistException);
export var ExtensionField$ = [3, n0, _EF,
    0,
    [_N, _V],
    [0, 0], 2
];
export var FromEmailAddressNotVerifiedException$ = [-3, n0, _FEANVE,
    { [_aQE]: [`FromEmailAddressNotVerified`, 400], [_e]: _c, [_hE]: 400 },
    [_FEA, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(FromEmailAddressNotVerifiedException$, FromEmailAddressNotVerifiedException);
export var GetAccountSendingEnabledResponse$ = [3, n0, _GASER,
    0,
    [_En],
    [2]
];
export var GetCustomVerificationEmailTemplateRequest$ = [3, n0, _GCVETR,
    0,
    [_TN],
    [0], 1
];
export var GetCustomVerificationEmailTemplateResponse$ = [3, n0, _GCVETRe,
    0,
    [_TN, _FEA, _TS, _TC, _SRURL, _FRURL],
    [0, 0, 0, 0, 0, 0]
];
export var GetIdentityDkimAttributesRequest$ = [3, n0, _GIDAR,
    0,
    [_Id],
    [64 | 0], 1
];
export var GetIdentityDkimAttributesResponse$ = [3, n0, _GIDARe,
    0,
    [_DA],
    [() => DkimAttributes], 1
];
export var GetIdentityMailFromDomainAttributesRequest$ = [3, n0, _GIMFDAR,
    0,
    [_Id],
    [64 | 0], 1
];
export var GetIdentityMailFromDomainAttributesResponse$ = [3, n0, _GIMFDARe,
    0,
    [_MFDA],
    [() => MailFromDomainAttributes], 1
];
export var GetIdentityNotificationAttributesRequest$ = [3, n0, _GINAR,
    0,
    [_Id],
    [64 | 0], 1
];
export var GetIdentityNotificationAttributesResponse$ = [3, n0, _GINARe,
    0,
    [_NA],
    [() => NotificationAttributes], 1
];
export var GetIdentityPoliciesRequest$ = [3, n0, _GIPR,
    0,
    [_I, _PNo],
    [0, 64 | 0], 2
];
export var GetIdentityPoliciesResponse$ = [3, n0, _GIPRe,
    0,
    [_P],
    [128 | 0], 1
];
export var GetIdentityVerificationAttributesRequest$ = [3, n0, _GIVAR,
    0,
    [_Id],
    [64 | 0], 1
];
export var GetIdentityVerificationAttributesResponse$ = [3, n0, _GIVARe,
    0,
    [_VA],
    [() => VerificationAttributes], 1
];
export var GetSendQuotaResponse$ = [3, n0, _GSQR,
    0,
    [_MHS, _MSR, _SLH],
    [1, 1, 1]
];
export var GetSendStatisticsResponse$ = [3, n0, _GSSR,
    0,
    [_SDP],
    [() => SendDataPointList]
];
export var GetTemplateRequest$ = [3, n0, _GTR,
    0,
    [_TN],
    [0], 1
];
export var GetTemplateResponse$ = [3, n0, _GTRe,
    0,
    [_Te],
    [() => Template$]
];
export var IdentityDkimAttributes$ = [3, n0, _IDA,
    0,
    [_DE, _DVSk, _DT],
    [2, 0, 64 | 0], 2
];
export var IdentityMailFromDomainAttributes$ = [3, n0, _IMFDA,
    0,
    [_MFD, _MFDS, _BOMXF],
    [0, 0, 0], 3
];
export var IdentityNotificationAttributes$ = [3, n0, _INA,
    0,
    [_BTo, _CT, _DTe, _FE, _HIBNE, _HICNE, _HIDNE],
    [0, 0, 0, 2, 2, 2, 2], 4
];
export var IdentityVerificationAttributes$ = [3, n0, _IVA,
    0,
    [_VS, _VT],
    [0, 0], 1
];
export var InvalidCloudWatchDestinationException$ = [-3, n0, _ICWDE,
    { [_aQE]: [`InvalidCloudWatchDestination`, 400], [_e]: _c, [_hE]: 400 },
    [_CSN, _EDN, _m],
    [0, 0, 0]
];
TypeRegistry.for(n0).registerError(InvalidCloudWatchDestinationException$, InvalidCloudWatchDestinationException);
export var InvalidConfigurationSetException$ = [-3, n0, _ICSE,
    { [_aQE]: [`InvalidConfigurationSet`, 400], [_e]: _c, [_hE]: 400 },
    [_m],
    [0]
];
TypeRegistry.for(n0).registerError(InvalidConfigurationSetException$, InvalidConfigurationSetException);
export var InvalidDeliveryOptionsException$ = [-3, n0, _IDOE,
    { [_aQE]: [`InvalidDeliveryOptions`, 400], [_e]: _c, [_hE]: 400 },
    [_m],
    [0]
];
TypeRegistry.for(n0).registerError(InvalidDeliveryOptionsException$, InvalidDeliveryOptionsException);
export var InvalidFirehoseDestinationException$ = [-3, n0, _IFDE,
    { [_aQE]: [`InvalidFirehoseDestination`, 400], [_e]: _c, [_hE]: 400 },
    [_CSN, _EDN, _m],
    [0, 0, 0]
];
TypeRegistry.for(n0).registerError(InvalidFirehoseDestinationException$, InvalidFirehoseDestinationException);
export var InvalidLambdaFunctionException$ = [-3, n0, _ILFE,
    { [_aQE]: [`InvalidLambdaFunction`, 400], [_e]: _c, [_hE]: 400 },
    [_FA, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(InvalidLambdaFunctionException$, InvalidLambdaFunctionException);
export var InvalidPolicyException$ = [-3, n0, _IPE,
    { [_aQE]: [`InvalidPolicy`, 400], [_e]: _c, [_hE]: 400 },
    [_m],
    [0]
];
TypeRegistry.for(n0).registerError(InvalidPolicyException$, InvalidPolicyException);
export var InvalidRenderingParameterException$ = [-3, n0, _IRPE,
    { [_aQE]: [`InvalidRenderingParameter`, 400], [_e]: _c, [_hE]: 400 },
    [_TN, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(InvalidRenderingParameterException$, InvalidRenderingParameterException);
export var InvalidS3ConfigurationException$ = [-3, n0, _ISCE,
    { [_aQE]: [`InvalidS3Configuration`, 400], [_e]: _c, [_hE]: 400 },
    [_Bu, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(InvalidS3ConfigurationException$, InvalidS3ConfigurationException);
export var InvalidSNSDestinationException$ = [-3, n0, _ISNSDE,
    { [_aQE]: [`InvalidSNSDestination`, 400], [_e]: _c, [_hE]: 400 },
    [_CSN, _EDN, _m],
    [0, 0, 0]
];
TypeRegistry.for(n0).registerError(InvalidSNSDestinationException$, InvalidSNSDestinationException);
export var InvalidSnsTopicException$ = [-3, n0, _ISTE,
    { [_aQE]: [`InvalidSnsTopic`, 400], [_e]: _c, [_hE]: 400 },
    [_To, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(InvalidSnsTopicException$, InvalidSnsTopicException);
export var InvalidTemplateException$ = [-3, n0, _ITE,
    { [_aQE]: [`InvalidTemplate`, 400], [_e]: _c, [_hE]: 400 },
    [_TN, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(InvalidTemplateException$, InvalidTemplateException);
export var InvalidTrackingOptionsException$ = [-3, n0, _ITOE,
    { [_aQE]: [`InvalidTrackingOptions`, 400], [_e]: _c, [_hE]: 400 },
    [_m],
    [0]
];
TypeRegistry.for(n0).registerError(InvalidTrackingOptionsException$, InvalidTrackingOptionsException);
export var KinesisFirehoseDestination$ = [3, n0, _KFD,
    0,
    [_IAMRARN, _DSARN],
    [0, 0], 2
];
export var LambdaAction$ = [3, n0, _LA,
    0,
    [_FA, _TA, _IT],
    [0, 0, 0], 1
];
export var LimitExceededException$ = [-3, n0, _LEE,
    { [_aQE]: [`LimitExceeded`, 400], [_e]: _c, [_hE]: 400 },
    [_m],
    [0]
];
TypeRegistry.for(n0).registerError(LimitExceededException$, LimitExceededException);
export var ListConfigurationSetsRequest$ = [3, n0, _LCSR,
    0,
    [_NT, _MIa],
    [0, 1]
];
export var ListConfigurationSetsResponse$ = [3, n0, _LCSRi,
    0,
    [_CSo, _NT],
    [() => ConfigurationSets, 0]
];
export var ListCustomVerificationEmailTemplatesRequest$ = [3, n0, _LCVETR,
    0,
    [_NT, _MR],
    [0, 1]
];
export var ListCustomVerificationEmailTemplatesResponse$ = [3, n0, _LCVETRi,
    0,
    [_CVETu, _NT],
    [() => CustomVerificationEmailTemplates, 0]
];
export var ListIdentitiesRequest$ = [3, n0, _LIR,
    0,
    [_ITd, _NT, _MIa],
    [0, 0, 1]
];
export var ListIdentitiesResponse$ = [3, n0, _LIRi,
    0,
    [_Id, _NT],
    [64 | 0, 0], 1
];
export var ListIdentityPoliciesRequest$ = [3, n0, _LIPR,
    0,
    [_I],
    [0], 1
];
export var ListIdentityPoliciesResponse$ = [3, n0, _LIPRi,
    0,
    [_PNo],
    [64 | 0], 1
];
export var ListReceiptFiltersRequest$ = [3, n0, _LRFR,
    0,
    [],
    []
];
export var ListReceiptFiltersResponse$ = [3, n0, _LRFRi,
    0,
    [_Fi],
    [() => ReceiptFilterList]
];
export var ListReceiptRuleSetsRequest$ = [3, n0, _LRRSR,
    0,
    [_NT],
    [0]
];
export var ListReceiptRuleSetsResponse$ = [3, n0, _LRRSRi,
    0,
    [_RS, _NT],
    [() => ReceiptRuleSetsLists, 0]
];
export var ListTemplatesRequest$ = [3, n0, _LTR,
    0,
    [_NT, _MIa],
    [0, 1]
];
export var ListTemplatesResponse$ = [3, n0, _LTRi,
    0,
    [_TM, _NT],
    [() => TemplateMetadataList, 0]
];
export var ListVerifiedEmailAddressesResponse$ = [3, n0, _LVEAR,
    0,
    [_VEA],
    [64 | 0]
];
export var MailFromDomainNotVerifiedException$ = [-3, n0, _MFDNVE,
    { [_aQE]: [`MailFromDomainNotVerifiedException`, 400], [_e]: _c, [_hE]: 400 },
    [_m],
    [0]
];
TypeRegistry.for(n0).registerError(MailFromDomainNotVerifiedException$, MailFromDomainNotVerifiedException);
export var Message$ = [3, n0, _M,
    0,
    [_Su, _B],
    [() => Content$, () => Body$], 2
];
export var MessageDsn$ = [3, n0, _MD,
    0,
    [_RM, _AD, _EFx],
    [0, 4, () => ExtensionFieldList], 1
];
export var MessageRejected$ = [-3, n0, _MRe,
    { [_aQE]: [`MessageRejected`, 400], [_e]: _c, [_hE]: 400 },
    [_m],
    [0]
];
TypeRegistry.for(n0).registerError(MessageRejected$, MessageRejected);
export var MessageTag$ = [3, n0, _MT,
    0,
    [_N, _V],
    [0, 0], 2
];
export var MissingRenderingAttributeException$ = [-3, n0, _MRAE,
    { [_aQE]: [`MissingRenderingAttribute`, 400], [_e]: _c, [_hE]: 400 },
    [_TN, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(MissingRenderingAttributeException$, MissingRenderingAttributeException);
export var ProductionAccessNotGrantedException$ = [-3, n0, _PANGE,
    { [_aQE]: [`ProductionAccessNotGranted`, 400], [_e]: _c, [_hE]: 400 },
    [_m],
    [0]
];
TypeRegistry.for(n0).registerError(ProductionAccessNotGrantedException$, ProductionAccessNotGrantedException);
export var PutConfigurationSetDeliveryOptionsRequest$ = [3, n0, _PCSDOR,
    0,
    [_CSN, _DO],
    [0, () => DeliveryOptions$], 1
];
export var PutConfigurationSetDeliveryOptionsResponse$ = [3, n0, _PCSDORu,
    0,
    [],
    []
];
export var PutIdentityPolicyRequest$ = [3, n0, _PIPR,
    0,
    [_I, _PN, _Po],
    [0, 0, 0], 3
];
export var PutIdentityPolicyResponse$ = [3, n0, _PIPRu,
    0,
    [],
    []
];
export var RawMessage$ = [3, n0, _RMa,
    0,
    [_Da],
    [21], 1
];
export var ReceiptAction$ = [3, n0, _RAe,
    0,
    [_SA, _BA, _WA, _LA, _SAt, _AHA, _SNSA, _CA],
    [() => S3Action$, () => BounceAction$, () => WorkmailAction$, () => LambdaAction$, () => StopAction$, () => AddHeaderAction$, () => SNSAction$, () => ConnectAction$]
];
export var ReceiptFilter$ = [3, n0, _RF,
    0,
    [_N, _IF],
    [0, () => ReceiptIpFilter$], 2
];
export var ReceiptIpFilter$ = [3, n0, _RIF,
    0,
    [_Po, _Ci],
    [0, 0], 2
];
export var ReceiptRule$ = [3, n0, _RR,
    0,
    [_N, _En, _TP, _Re, _Ac, _SE],
    [0, 2, 0, 64 | 0, () => ReceiptActionsList, 2], 1
];
export var ReceiptRuleSetMetadata$ = [3, n0, _RRSM,
    0,
    [_N, _CTr],
    [0, 4]
];
export var RecipientDsnFields$ = [3, n0, _RDF,
    0,
    [_Act, _St, _FR, _RMe, _DCi, _LAD, _EFx],
    [0, 0, 0, 0, 0, 4, () => ExtensionFieldList], 2
];
export var ReorderReceiptRuleSetRequest$ = [3, n0, _RRRSR,
    0,
    [_RSN, _RNu],
    [0, 64 | 0], 2
];
export var ReorderReceiptRuleSetResponse$ = [3, n0, _RRRSRe,
    0,
    [],
    []
];
export var ReputationOptions$ = [3, n0, _RO,
    0,
    [_SEe, _RME, _LFS],
    [2, 2, 4]
];
export var RuleDoesNotExistException$ = [-3, n0, _RDNEE,
    { [_aQE]: [`RuleDoesNotExist`, 400], [_e]: _c, [_hE]: 400 },
    [_N, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(RuleDoesNotExistException$, RuleDoesNotExistException);
export var RuleSetDoesNotExistException$ = [-3, n0, _RSDNEE,
    { [_aQE]: [`RuleSetDoesNotExist`, 400], [_e]: _c, [_hE]: 400 },
    [_N, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(RuleSetDoesNotExistException$, RuleSetDoesNotExistException);
export var S3Action$ = [3, n0, _SA,
    0,
    [_BN, _TA, _OKP, _KKA, _IRA],
    [0, 0, 0, 0, 0], 1
];
export var SendBounceRequest$ = [3, n0, _SBR,
    0,
    [_OMI, _BS, _BRIL, _Ex, _MD, _BSA],
    [0, 0, () => BouncedRecipientInfoList, 0, () => MessageDsn$, 0], 3
];
export var SendBounceResponse$ = [3, n0, _SBRe,
    0,
    [_MI],
    [0]
];
export var SendBulkTemplatedEmailRequest$ = [3, n0, _SBTER,
    0,
    [_So, _Te, _DTD, _De, _SAo, _RTA, _RP, _RPA, _CSN, _DTef, _TAe],
    [0, 0, 0, () => BulkEmailDestinationList, 0, 64 | 0, 0, 0, 0, () => MessageTagList, 0], 4
];
export var SendBulkTemplatedEmailResponse$ = [3, n0, _SBTERe,
    0,
    [_St],
    [() => BulkEmailDestinationStatusList], 1
];
export var SendCustomVerificationEmailRequest$ = [3, n0, _SCVER,
    0,
    [_EA, _TN, _CSN],
    [0, 0, 0], 2
];
export var SendCustomVerificationEmailResponse$ = [3, n0, _SCVERe,
    0,
    [_MI],
    [0]
];
export var SendDataPoint$ = [3, n0, _SDPe,
    0,
    [_Ti, _DAe, _Bo, _Co, _Rej],
    [4, 1, 1, 1, 1]
];
export var SendEmailRequest$ = [3, n0, _SER,
    0,
    [_So, _D, _M, _RTA, _RP, _SAo, _RPA, _Ta, _CSN],
    [0, () => Destination$, () => Message$, 64 | 0, 0, 0, 0, () => MessageTagList, 0], 3
];
export var SendEmailResponse$ = [3, n0, _SERe,
    0,
    [_MI],
    [0], 1
];
export var SendRawEmailRequest$ = [3, n0, _SRER,
    0,
    [_RMa, _So, _De, _FAr, _SAo, _RPA, _Ta, _CSN],
    [() => RawMessage$, 0, 64 | 0, 0, 0, 0, () => MessageTagList, 0], 1
];
export var SendRawEmailResponse$ = [3, n0, _SRERe,
    0,
    [_MI],
    [0], 1
];
export var SendTemplatedEmailRequest$ = [3, n0, _STER,
    0,
    [_So, _D, _Te, _TD, _RTA, _RP, _SAo, _RPA, _Ta, _CSN, _TAe],
    [0, () => Destination$, 0, 0, 64 | 0, 0, 0, 0, () => MessageTagList, 0, 0], 4
];
export var SendTemplatedEmailResponse$ = [3, n0, _STERe,
    0,
    [_MI],
    [0], 1
];
export var SetActiveReceiptRuleSetRequest$ = [3, n0, _SARRSR,
    0,
    [_RSN],
    [0]
];
export var SetActiveReceiptRuleSetResponse$ = [3, n0, _SARRSRe,
    0,
    [],
    []
];
export var SetIdentityDkimEnabledRequest$ = [3, n0, _SIDER,
    0,
    [_I, _DE],
    [0, 2], 2
];
export var SetIdentityDkimEnabledResponse$ = [3, n0, _SIDERe,
    0,
    [],
    []
];
export var SetIdentityFeedbackForwardingEnabledRequest$ = [3, n0, _SIFFER,
    0,
    [_I, _FE],
    [0, 2], 2
];
export var SetIdentityFeedbackForwardingEnabledResponse$ = [3, n0, _SIFFERe,
    0,
    [],
    []
];
export var SetIdentityHeadersInNotificationsEnabledRequest$ = [3, n0, _SIHINER,
    0,
    [_I, _NTo, _En],
    [0, 0, 2], 3
];
export var SetIdentityHeadersInNotificationsEnabledResponse$ = [3, n0, _SIHINERe,
    0,
    [],
    []
];
export var SetIdentityMailFromDomainRequest$ = [3, n0, _SIMFDR,
    0,
    [_I, _MFD, _BOMXF],
    [0, 0, 0], 1
];
export var SetIdentityMailFromDomainResponse$ = [3, n0, _SIMFDRe,
    0,
    [],
    []
];
export var SetIdentityNotificationTopicRequest$ = [3, n0, _SINTR,
    0,
    [_I, _NTo, _ST],
    [0, 0, 0], 2
];
export var SetIdentityNotificationTopicResponse$ = [3, n0, _SINTRe,
    0,
    [],
    []
];
export var SetReceiptRulePositionRequest$ = [3, n0, _SRRPR,
    0,
    [_RSN, _RN, _A],
    [0, 0, 0], 2
];
export var SetReceiptRulePositionResponse$ = [3, n0, _SRRPRe,
    0,
    [],
    []
];
export var SNSAction$ = [3, n0, _SNSA,
    0,
    [_TA, _Enc],
    [0, 0], 1
];
export var SNSDestination$ = [3, n0, _SNSD,
    0,
    [_TARN],
    [0], 1
];
export var StopAction$ = [3, n0, _SAt,
    0,
    [_Sc, _TA],
    [0, 0], 1
];
export var Template$ = [3, n0, _Te,
    0,
    [_TN, _SP, _TPe, _HP],
    [0, 0, 0, 0], 1
];
export var TemplateDoesNotExistException$ = [-3, n0, _TDNEE,
    { [_aQE]: [`TemplateDoesNotExist`, 400], [_e]: _c, [_hE]: 400 },
    [_TN, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(TemplateDoesNotExistException$, TemplateDoesNotExistException);
export var TemplateMetadata$ = [3, n0, _TMe,
    0,
    [_N, _CTr],
    [0, 4]
];
export var TestRenderTemplateRequest$ = [3, n0, _TRTR,
    0,
    [_TN, _TD],
    [0, 0], 2
];
export var TestRenderTemplateResponse$ = [3, n0, _TRTRe,
    0,
    [_RTe],
    [0]
];
export var TrackingOptions$ = [3, n0, _TO,
    0,
    [_CRD],
    [0]
];
export var TrackingOptionsAlreadyExistsException$ = [-3, n0, _TOAEE,
    { [_aQE]: [`TrackingOptionsAlreadyExistsException`, 400], [_e]: _c, [_hE]: 400 },
    [_CSN, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(TrackingOptionsAlreadyExistsException$, TrackingOptionsAlreadyExistsException);
export var TrackingOptionsDoesNotExistException$ = [-3, n0, _TODNEE,
    { [_aQE]: [`TrackingOptionsDoesNotExistException`, 400], [_e]: _c, [_hE]: 400 },
    [_CSN, _m],
    [0, 0]
];
TypeRegistry.for(n0).registerError(TrackingOptionsDoesNotExistException$, TrackingOptionsDoesNotExistException);
export var UpdateAccountSendingEnabledRequest$ = [3, n0, _UASER,
    0,
    [_En],
    [2]
];
export var UpdateConfigurationSetEventDestinationRequest$ = [3, n0, _UCSEDR,
    0,
    [_CSN, _ED],
    [0, () => EventDestination$], 2
];
export var UpdateConfigurationSetEventDestinationResponse$ = [3, n0, _UCSEDRp,
    0,
    [],
    []
];
export var UpdateConfigurationSetReputationMetricsEnabledRequest$ = [3, n0, _UCSRMER,
    0,
    [_CSN, _En],
    [0, 2], 2
];
export var UpdateConfigurationSetSendingEnabledRequest$ = [3, n0, _UCSSER,
    0,
    [_CSN, _En],
    [0, 2], 2
];
export var UpdateConfigurationSetTrackingOptionsRequest$ = [3, n0, _UCSTOR,
    0,
    [_CSN, _TO],
    [0, () => TrackingOptions$], 2
];
export var UpdateConfigurationSetTrackingOptionsResponse$ = [3, n0, _UCSTORp,
    0,
    [],
    []
];
export var UpdateCustomVerificationEmailTemplateRequest$ = [3, n0, _UCVETR,
    0,
    [_TN, _FEA, _TS, _TC, _SRURL, _FRURL],
    [0, 0, 0, 0, 0, 0], 1
];
export var UpdateReceiptRuleRequest$ = [3, n0, _URRR,
    0,
    [_RSN, _Ru],
    [0, () => ReceiptRule$], 2
];
export var UpdateReceiptRuleResponse$ = [3, n0, _URRRp,
    0,
    [],
    []
];
export var UpdateTemplateRequest$ = [3, n0, _UTR,
    0,
    [_Te],
    [() => Template$], 1
];
export var UpdateTemplateResponse$ = [3, n0, _UTRp,
    0,
    [],
    []
];
export var VerifyDomainDkimRequest$ = [3, n0, _VDDR,
    0,
    [_Do],
    [0], 1
];
export var VerifyDomainDkimResponse$ = [3, n0, _VDDRe,
    0,
    [_DT],
    [64 | 0], 1
];
export var VerifyDomainIdentityRequest$ = [3, n0, _VDIR,
    0,
    [_Do],
    [0], 1
];
export var VerifyDomainIdentityResponse$ = [3, n0, _VDIRe,
    0,
    [_VT],
    [0], 1
];
export var VerifyEmailAddressRequest$ = [3, n0, _VEAR,
    0,
    [_EA],
    [0], 1
];
export var VerifyEmailIdentityRequest$ = [3, n0, _VEIR,
    0,
    [_EA],
    [0], 1
];
export var VerifyEmailIdentityResponse$ = [3, n0, _VEIRe,
    0,
    [],
    []
];
export var WorkmailAction$ = [3, n0, _WA,
    0,
    [_OA, _TA],
    [0, 0], 1
];
var __Unit = "unit";
export var SESServiceException$ = [-3, _s, "SESServiceException", 0, [], []];
TypeRegistry.for(_s).registerError(SESServiceException$, SESServiceException);
var AddressList = 64 | 0;
var BouncedRecipientInfoList = [1, n0, _BRIL,
    0, () => BouncedRecipientInfo$
];
var BulkEmailDestinationList = [1, n0, _BEDL,
    0, () => BulkEmailDestination$
];
var BulkEmailDestinationStatusList = [1, n0, _BEDSL,
    0, () => BulkEmailDestinationStatus$
];
var CloudWatchDimensionConfigurations = [1, n0, _CWDCl,
    0, () => CloudWatchDimensionConfiguration$
];
var ConfigurationSetAttributeList = 64 | 0;
var ConfigurationSets = [1, n0, _CSo,
    0, () => ConfigurationSet$
];
var CustomVerificationEmailTemplates = [1, n0, _CVETu,
    0, () => CustomVerificationEmailTemplate$
];
var EventDestinations = [1, n0, _EDv,
    0, () => EventDestination$
];
var EventTypes = 64 | 0;
var ExtensionFieldList = [1, n0, _EFL,
    0, () => ExtensionField$
];
var IdentityList = 64 | 0;
var MessageTagList = [1, n0, _MTL,
    0, () => MessageTag$
];
var PolicyNameList = 64 | 0;
var ReceiptActionsList = [1, n0, _RAL,
    0, () => ReceiptAction$
];
var ReceiptFilterList = [1, n0, _RFL,
    0, () => ReceiptFilter$
];
var ReceiptRuleNamesList = 64 | 0;
var ReceiptRuleSetsLists = [1, n0, _RRSL,
    0, () => ReceiptRuleSetMetadata$
];
var ReceiptRulesList = [1, n0, _RRL,
    0, () => ReceiptRule$
];
var RecipientsList = 64 | 0;
var SendDataPointList = [1, n0, _SDPL,
    0, () => SendDataPoint$
];
var TemplateMetadataList = [1, n0, _TML,
    0, () => TemplateMetadata$
];
var VerificationTokenList = 64 | 0;
var DkimAttributes = [2, n0, _DA,
    0, 0, () => IdentityDkimAttributes$
];
var MailFromDomainAttributes = [2, n0, _MFDA,
    0, 0, () => IdentityMailFromDomainAttributes$
];
var NotificationAttributes = [2, n0, _NA,
    0, 0, () => IdentityNotificationAttributes$
];
var PolicyMap = 128 | 0;
var VerificationAttributes = [2, n0, _VA,
    0, 0, () => IdentityVerificationAttributes$
];
export var CloneReceiptRuleSet$ = [9, n0, _CRRS,
    0, () => CloneReceiptRuleSetRequest$, () => CloneReceiptRuleSetResponse$
];
export var CreateConfigurationSet$ = [9, n0, _CCS,
    0, () => CreateConfigurationSetRequest$, () => CreateConfigurationSetResponse$
];
export var CreateConfigurationSetEventDestination$ = [9, n0, _CCSED,
    0, () => CreateConfigurationSetEventDestinationRequest$, () => CreateConfigurationSetEventDestinationResponse$
];
export var CreateConfigurationSetTrackingOptions$ = [9, n0, _CCSTO,
    0, () => CreateConfigurationSetTrackingOptionsRequest$, () => CreateConfigurationSetTrackingOptionsResponse$
];
export var CreateCustomVerificationEmailTemplate$ = [9, n0, _CCVET,
    0, () => CreateCustomVerificationEmailTemplateRequest$, () => __Unit
];
export var CreateReceiptFilter$ = [9, n0, _CRF,
    0, () => CreateReceiptFilterRequest$, () => CreateReceiptFilterResponse$
];
export var CreateReceiptRule$ = [9, n0, _CRR,
    0, () => CreateReceiptRuleRequest$, () => CreateReceiptRuleResponse$
];
export var CreateReceiptRuleSet$ = [9, n0, _CRRSr,
    0, () => CreateReceiptRuleSetRequest$, () => CreateReceiptRuleSetResponse$
];
export var CreateTemplate$ = [9, n0, _CTre,
    0, () => CreateTemplateRequest$, () => CreateTemplateResponse$
];
export var DeleteConfigurationSet$ = [9, n0, _DCS,
    0, () => DeleteConfigurationSetRequest$, () => DeleteConfigurationSetResponse$
];
export var DeleteConfigurationSetEventDestination$ = [9, n0, _DCSED,
    0, () => DeleteConfigurationSetEventDestinationRequest$, () => DeleteConfigurationSetEventDestinationResponse$
];
export var DeleteConfigurationSetTrackingOptions$ = [9, n0, _DCSTO,
    0, () => DeleteConfigurationSetTrackingOptionsRequest$, () => DeleteConfigurationSetTrackingOptionsResponse$
];
export var DeleteCustomVerificationEmailTemplate$ = [9, n0, _DCVET,
    0, () => DeleteCustomVerificationEmailTemplateRequest$, () => __Unit
];
export var DeleteIdentity$ = [9, n0, _DI,
    0, () => DeleteIdentityRequest$, () => DeleteIdentityResponse$
];
export var DeleteIdentityPolicy$ = [9, n0, _DIP,
    0, () => DeleteIdentityPolicyRequest$, () => DeleteIdentityPolicyResponse$
];
export var DeleteReceiptFilter$ = [9, n0, _DRF,
    0, () => DeleteReceiptFilterRequest$, () => DeleteReceiptFilterResponse$
];
export var DeleteReceiptRule$ = [9, n0, _DRR,
    0, () => DeleteReceiptRuleRequest$, () => DeleteReceiptRuleResponse$
];
export var DeleteReceiptRuleSet$ = [9, n0, _DRRS,
    0, () => DeleteReceiptRuleSetRequest$, () => DeleteReceiptRuleSetResponse$
];
export var DeleteTemplate$ = [9, n0, _DTel,
    0, () => DeleteTemplateRequest$, () => DeleteTemplateResponse$
];
export var DeleteVerifiedEmailAddress$ = [9, n0, _DVEA,
    0, () => DeleteVerifiedEmailAddressRequest$, () => __Unit
];
export var DescribeActiveReceiptRuleSet$ = [9, n0, _DARRS,
    0, () => DescribeActiveReceiptRuleSetRequest$, () => DescribeActiveReceiptRuleSetResponse$
];
export var DescribeConfigurationSet$ = [9, n0, _DCSe,
    0, () => DescribeConfigurationSetRequest$, () => DescribeConfigurationSetResponse$
];
export var DescribeReceiptRule$ = [9, n0, _DRRe,
    0, () => DescribeReceiptRuleRequest$, () => DescribeReceiptRuleResponse$
];
export var DescribeReceiptRuleSet$ = [9, n0, _DRRSe,
    0, () => DescribeReceiptRuleSetRequest$, () => DescribeReceiptRuleSetResponse$
];
export var GetAccountSendingEnabled$ = [9, n0, _GASE,
    0, () => __Unit, () => GetAccountSendingEnabledResponse$
];
export var GetCustomVerificationEmailTemplate$ = [9, n0, _GCVET,
    0, () => GetCustomVerificationEmailTemplateRequest$, () => GetCustomVerificationEmailTemplateResponse$
];
export var GetIdentityDkimAttributes$ = [9, n0, _GIDA,
    0, () => GetIdentityDkimAttributesRequest$, () => GetIdentityDkimAttributesResponse$
];
export var GetIdentityMailFromDomainAttributes$ = [9, n0, _GIMFDA,
    0, () => GetIdentityMailFromDomainAttributesRequest$, () => GetIdentityMailFromDomainAttributesResponse$
];
export var GetIdentityNotificationAttributes$ = [9, n0, _GINA,
    0, () => GetIdentityNotificationAttributesRequest$, () => GetIdentityNotificationAttributesResponse$
];
export var GetIdentityPolicies$ = [9, n0, _GIP,
    0, () => GetIdentityPoliciesRequest$, () => GetIdentityPoliciesResponse$
];
export var GetIdentityVerificationAttributes$ = [9, n0, _GIVA,
    0, () => GetIdentityVerificationAttributesRequest$, () => GetIdentityVerificationAttributesResponse$
];
export var GetSendQuota$ = [9, n0, _GSQ,
    0, () => __Unit, () => GetSendQuotaResponse$
];
export var GetSendStatistics$ = [9, n0, _GSS,
    0, () => __Unit, () => GetSendStatisticsResponse$
];
export var GetTemplate$ = [9, n0, _GT,
    0, () => GetTemplateRequest$, () => GetTemplateResponse$
];
export var ListConfigurationSets$ = [9, n0, _LCS,
    0, () => ListConfigurationSetsRequest$, () => ListConfigurationSetsResponse$
];
export var ListCustomVerificationEmailTemplates$ = [9, n0, _LCVET,
    0, () => ListCustomVerificationEmailTemplatesRequest$, () => ListCustomVerificationEmailTemplatesResponse$
];
export var ListIdentities$ = [9, n0, _LI,
    0, () => ListIdentitiesRequest$, () => ListIdentitiesResponse$
];
export var ListIdentityPolicies$ = [9, n0, _LIP,
    0, () => ListIdentityPoliciesRequest$, () => ListIdentityPoliciesResponse$
];
export var ListReceiptFilters$ = [9, n0, _LRF,
    0, () => ListReceiptFiltersRequest$, () => ListReceiptFiltersResponse$
];
export var ListReceiptRuleSets$ = [9, n0, _LRRS,
    0, () => ListReceiptRuleSetsRequest$, () => ListReceiptRuleSetsResponse$
];
export var ListTemplates$ = [9, n0, _LT,
    0, () => ListTemplatesRequest$, () => ListTemplatesResponse$
];
export var ListVerifiedEmailAddresses$ = [9, n0, _LVEA,
    0, () => __Unit, () => ListVerifiedEmailAddressesResponse$
];
export var PutConfigurationSetDeliveryOptions$ = [9, n0, _PCSDO,
    0, () => PutConfigurationSetDeliveryOptionsRequest$, () => PutConfigurationSetDeliveryOptionsResponse$
];
export var PutIdentityPolicy$ = [9, n0, _PIP,
    0, () => PutIdentityPolicyRequest$, () => PutIdentityPolicyResponse$
];
export var ReorderReceiptRuleSet$ = [9, n0, _RRRS,
    0, () => ReorderReceiptRuleSetRequest$, () => ReorderReceiptRuleSetResponse$
];
export var SendBounce$ = [9, n0, _SB,
    0, () => SendBounceRequest$, () => SendBounceResponse$
];
export var SendBulkTemplatedEmail$ = [9, n0, _SBTE,
    0, () => SendBulkTemplatedEmailRequest$, () => SendBulkTemplatedEmailResponse$
];
export var SendCustomVerificationEmail$ = [9, n0, _SCVE,
    0, () => SendCustomVerificationEmailRequest$, () => SendCustomVerificationEmailResponse$
];
export var SendEmail$ = [9, n0, _SEen,
    0, () => SendEmailRequest$, () => SendEmailResponse$
];
export var SendRawEmail$ = [9, n0, _SRE,
    0, () => SendRawEmailRequest$, () => SendRawEmailResponse$
];
export var SendTemplatedEmail$ = [9, n0, _STE,
    0, () => SendTemplatedEmailRequest$, () => SendTemplatedEmailResponse$
];
export var SetActiveReceiptRuleSet$ = [9, n0, _SARRS,
    0, () => SetActiveReceiptRuleSetRequest$, () => SetActiveReceiptRuleSetResponse$
];
export var SetIdentityDkimEnabled$ = [9, n0, _SIDE,
    0, () => SetIdentityDkimEnabledRequest$, () => SetIdentityDkimEnabledResponse$
];
export var SetIdentityFeedbackForwardingEnabled$ = [9, n0, _SIFFE,
    0, () => SetIdentityFeedbackForwardingEnabledRequest$, () => SetIdentityFeedbackForwardingEnabledResponse$
];
export var SetIdentityHeadersInNotificationsEnabled$ = [9, n0, _SIHINE,
    0, () => SetIdentityHeadersInNotificationsEnabledRequest$, () => SetIdentityHeadersInNotificationsEnabledResponse$
];
export var SetIdentityMailFromDomain$ = [9, n0, _SIMFD,
    0, () => SetIdentityMailFromDomainRequest$, () => SetIdentityMailFromDomainResponse$
];
export var SetIdentityNotificationTopic$ = [9, n0, _SINT,
    0, () => SetIdentityNotificationTopicRequest$, () => SetIdentityNotificationTopicResponse$
];
export var SetReceiptRulePosition$ = [9, n0, _SRRP,
    0, () => SetReceiptRulePositionRequest$, () => SetReceiptRulePositionResponse$
];
export var TestRenderTemplate$ = [9, n0, _TRT,
    0, () => TestRenderTemplateRequest$, () => TestRenderTemplateResponse$
];
export var UpdateAccountSendingEnabled$ = [9, n0, _UASE,
    0, () => UpdateAccountSendingEnabledRequest$, () => __Unit
];
export var UpdateConfigurationSetEventDestination$ = [9, n0, _UCSED,
    0, () => UpdateConfigurationSetEventDestinationRequest$, () => UpdateConfigurationSetEventDestinationResponse$
];
export var UpdateConfigurationSetReputationMetricsEnabled$ = [9, n0, _UCSRME,
    0, () => UpdateConfigurationSetReputationMetricsEnabledRequest$, () => __Unit
];
export var UpdateConfigurationSetSendingEnabled$ = [9, n0, _UCSSE,
    0, () => UpdateConfigurationSetSendingEnabledRequest$, () => __Unit
];
export var UpdateConfigurationSetTrackingOptions$ = [9, n0, _UCSTO,
    0, () => UpdateConfigurationSetTrackingOptionsRequest$, () => UpdateConfigurationSetTrackingOptionsResponse$
];
export var UpdateCustomVerificationEmailTemplate$ = [9, n0, _UCVET,
    0, () => UpdateCustomVerificationEmailTemplateRequest$, () => __Unit
];
export var UpdateReceiptRule$ = [9, n0, _URR,
    0, () => UpdateReceiptRuleRequest$, () => UpdateReceiptRuleResponse$
];
export var UpdateTemplate$ = [9, n0, _UT,
    0, () => UpdateTemplateRequest$, () => UpdateTemplateResponse$
];
export var VerifyDomainDkim$ = [9, n0, _VDD,
    0, () => VerifyDomainDkimRequest$, () => VerifyDomainDkimResponse$
];
export var VerifyDomainIdentity$ = [9, n0, _VDI,
    0, () => VerifyDomainIdentityRequest$, () => VerifyDomainIdentityResponse$
];
export var VerifyEmailAddress$ = [9, n0, _VEAe,
    0, () => VerifyEmailAddressRequest$, () => __Unit
];
export var VerifyEmailIdentity$ = [9, n0, _VEI,
    0, () => VerifyEmailIdentityRequest$, () => VerifyEmailIdentityResponse$
];
