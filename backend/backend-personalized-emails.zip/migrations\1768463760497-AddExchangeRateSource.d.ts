import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddExchangeRateSource1768463760497 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1768463760497-AddExchangeRateSource.d.ts.map