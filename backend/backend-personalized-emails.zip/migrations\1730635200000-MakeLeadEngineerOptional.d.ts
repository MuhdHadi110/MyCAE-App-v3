import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class MakeLeadEngineerOptional1730635200000 implements MigrationInterface {
    name: string;
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1730635200000-MakeLeadEngineerOptional.d.ts.map