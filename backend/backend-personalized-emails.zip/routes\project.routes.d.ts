declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=project.routes.d.ts.map