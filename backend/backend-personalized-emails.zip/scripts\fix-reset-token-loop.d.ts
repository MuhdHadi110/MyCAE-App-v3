import 'reflect-metadata';
//# sourceMappingURL=fix-reset-token-loop.d.ts.map