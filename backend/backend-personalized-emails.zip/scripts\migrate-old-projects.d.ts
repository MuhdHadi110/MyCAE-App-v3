import 'reflect-metadata';
//# sourceMappingURL=migrate-old-projects.d.ts.map