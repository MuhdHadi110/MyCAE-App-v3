import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class SplitClientsIntoCompaniesContacts1736200000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1736200000000-SplitClientsIntoCompaniesContacts.d.ts.map