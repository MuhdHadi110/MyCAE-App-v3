import 'reflect-metadata';
//# sourceMappingURL=migrate-clients-to-companies.d.ts.map