import { MigrationInterface, QueryRunner } from "typeorm";
export declare class CreateIssuedPOsTable1763025100000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1763025100000-CreateIssuedPOsTable.d.ts.map