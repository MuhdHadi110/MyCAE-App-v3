import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class ConvertRolesToArray1734600000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1734600000000-ConvertRolesToArray.d.ts.map