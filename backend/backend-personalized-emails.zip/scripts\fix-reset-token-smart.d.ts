import 'reflect-metadata';
//# sourceMappingURL=fix-reset-token-smart.d.ts.map