import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddMultiCurrencySupport1734268000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1734268000000-AddMultiCurrencySupport.d.ts.map