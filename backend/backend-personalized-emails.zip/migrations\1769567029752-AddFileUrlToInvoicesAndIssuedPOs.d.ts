import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AddFileUrlToInvoicesAndIssuedPOs1769567029752 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1769567029752-AddFileUrlToInvoicesAndIssuedPOs.d.ts.map