declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=migration.routes.d.ts.map