import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class CreateAuditLogsTable1736300000000 implements MigrationInterface {
    name: string;
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1736300000000-CreateAuditLogsTable.d.ts.map