import 'reflect-metadata';
//# sourceMappingURL=delete-specific-user.d.ts.map