import { DataSource } from 'typeorm';
export declare const AppDataSource: DataSource;
export declare const initializeDatabase: () => Promise<DataSource>;
//# sourceMappingURL=database.d.ts.map