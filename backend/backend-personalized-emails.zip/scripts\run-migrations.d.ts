import 'reflect-metadata';
//# sourceMappingURL=run-migrations.d.ts.map