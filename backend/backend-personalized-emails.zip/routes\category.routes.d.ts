declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=category.routes.d.ts.map